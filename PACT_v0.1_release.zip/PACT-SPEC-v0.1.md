
# PACT Specification v0.1

**Status:** Draft  
**Version:** 0.1  

PACT™ is a declarative coordination language for structuring human–AI collaboration through explicit contracts.

PACT = Purpose · Assumptions · Constraints · Tests

## Core Sections

### PURPOSE
Declares the intended outcome.

### ASSUMPTIONS
Conditions taken as true.

### CONSTRAINTS
Boundaries on behavior.

### TESTS
Criteria for acceptable output.
