
# PACT™ Language

PACT™ is an open coordination language for specifying Purpose, Assumptions, Constraints, and Tests in human–AI collaboration.

This repository contains the official PACT Specification v0.1.

## Files
- PACT-SPEC-v0.1.md — Canonical specification
- examples/hello-world.pact — Minimal example

## License
To be determined.
